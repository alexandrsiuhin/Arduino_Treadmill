// main_init

long serial_Boundrate = 115200ul;

String signal_Message = "Treadmill here";
String password_Message = "Treadmill";

String connection_Message = "Connection ..";
String wait_connection_Message = "Wait connect..";
String disconnect_Message = "Disconnect";
String text_Message = "";


//boolean equal_init_Message = false;
boolean string_Complete = false;
boolean activation_Speed = false;
boolean activation_Treadmill = false;
boolean direction_Speed = true;

int r_Speed = 0;
int Speed = 0;
int last_Speed = 0;
int stop_Step = 1;
int stop_Step_safe_Zone = 0;
int safe_Zone = 0;
int stop_delay = 100;

const int PWM_range = 255;

#define out1 2 //direction pin1
#define out2 3 //direction pin2
#define out3 5 //speed